<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //Variáveis
        $valor_hora = 6.5;
        $horas = 200;
        $salario_bruto = $valor_hora * $horas;
        echo "<h2> o seu salário desse mês é: $salario_bruto.</h2>";
        echo "<br>";
        if ($salario_bruto <= 2250.29){
        echo "<h2>Não vai pagar IR</h2>";  
        }
        else {
            echo "<h2>Não vai pagar IR</h2>"; 
        }
        ?>
    </body>
</html>
