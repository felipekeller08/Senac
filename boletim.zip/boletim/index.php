<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Boletim</title>
    </head>
    <body>
        <?php
        // Boletim
        $prova = 7;
        $trabalho = 8;
        $media = ($prova + $trabalho) / 2;
        echo "<h1>Boletim - 2025";
        echo "<br>";
        if ($media >= 7){
            echo "A média é $media - PD";
        }
        else if ($media >= 4){
            echo "A média é $media: ED";
        }
        else { 
        echo "A média é $media: ND";    
        }
        ?>
    </body>
</html>
